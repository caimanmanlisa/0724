<template>
  <div class="home">
    <section class="part">
      <div class="top"><img src="../assets/logo.png" class="logo"/></div>
      <ul class="list_nav">
         <li>
              <a href="#"><img src="../assets/listnav_1.png"><p>极速贷</p></a>
         </li>
          <li>
              <a href="#"><img src="../assets/listnav_2.png"><p>信用卡</p></a>
         </li>
          <li>
              <a href="#"><img src="../assets/listnav_3.png"><p>大额贷</p></a>
         </li>
          <li>
              <a href="#"><img src="../assets/listnav_4.png"><p>智能贷</p></a>
         </li>
      </ul>
      <div class="banner"><img src="../assets/banner1.png"></div>
      </section>

   <section class="part">
       <div class="jsd">
           <h3>极速贷款</h3>
           <a href="#" class="more">更多贷款 ></a>
           <div class="jsd_cont">
                <ul class="jsd_tag">
                    <li><a href="#">超低费率1</a></li>
                    <li><a href="#">超低费超率2</a></li>
                    <li><a href="#">超低超费率3</a></li>
                    <li><a href="#">超低超费率4</a></li>
                    <li><a href="#">超低费率5</a></li>
                    <li><a href="#">超超低费率6</a></li>
                    <li><a href="#">超低费率7</a></li>
                    <li><a href="#">超低费超率8</a></li>
                </ul>
                <ul class="jsd_list">
                     <li>
                       <a href="#">
                           <p class="pic"><img src="../assets/jb_1.png"></p>
                           <h4>白条分期</h4>
                           <i class="jb">新</i>
                       </a>
                    </li>
                    <li>
                       <a href="#">
                           <p class="pic"><img src="../assets/jb_1.png"></p>
                           <h4>白条分期</h4>
                           <i class="jb">新</i>
                       </a>
                    </li>
                    <li>
                       <a href="#">
                           <p class="pic"><img src="../assets/jb_1.png"></p>
                           <h4>白条分期</h4>
                           <i class="jb">新</i>
                       </a>
                    </li>
                    <li>
                       <a href="#">
                           <p class="pic"><img src="../assets/jb_1.png"></p>
                           <h4>白条分期</h4>
                           <i class="jb">新</i>
                       </a>
                    </li>
                    <li>
                       <a href="#">
                           <p class="pic"><img src="../assets/jb_1.png"></p>
                           <h4>白条分期</h4>
                           <i class="jb">新</i>
                       </a>
                    </li>
                     <li>
                       <a href="#">
                           <p class="pic"><img src="../assets/jb_1.png"></p>
                           <h4>白条分期</h4>
                           <i class="jb">新</i>
                       </a>
                    </li>
                     <li>
                       <a href="#">
                           <p class="pic"><img src="../assets/jb_1.png"></p>
                           <h4>白条分期</h4>
                           <i class="jb">新</i>
                       </a>
                    </li>
                     <li>
                       <a href="#">
                           <p class="pic"><img src="../assets/jb_1.png"></p>
                           <h4>白条分期</h4>
                           <i class="jb">新</i>
                       </a>
                    </li>
                </ul>

           </div>
       </div>


   </section>

<section class="part">
    <div class="jsd">
          <h3>贷款攻略</h3>
           <a href="#" class="more">更多文章 ></a>
    </div>
    <ul class="loan_gl">
        <li>
             <a href="#">
                <img src="../assets/news_tit1.jpg" class="pic">
                 <div class="info">
                     <h4 class="title">钱有路贷款不还会怎样，贷款逾期的后果还是非常严重的</h4>
                     <p class="content">现在贷款时，对于征信查询都是特别严格的，也有一些平台，对于这些问题还是非常忽略的，其实个人征信是非常重要的，如果安全正规的平台几乎都是会查询。黑户其实是在不知不觉就会出现的，有时是由于没有很好的还款或者是水电费拖欠时间久了也会出现这种现象。下面我们来简单的了解一下钱有路贷款不还会怎样，贷款逾期的后果还是非常严重的。</p>
                     <p class="date">2019-07-26 10:26:00</p>
                 </div>
             </a>
        </li>
         <li>
             <a href="#">
                <img src="../assets/news_tit1.jpg" class="pic">
                 <div class="info">
                     <h4 class="title">钱有路贷款不还会怎样，贷款逾期的后果还是非常严重的</h4>
                     <p class="content">现在贷款时，对于征信查询都是特别严格的，也有一些平台，对于这些问题还是非常忽略的，其实个人征信是非常重要的，如果安全正规的平台几乎都是会查询。黑户其实是在不知不觉就会出现的，有时是由于没有很好的还款或者是水电费拖欠时间久了也会出现这种现象。下面我们来简单的了解一下钱有路贷款不还会怎样，贷款逾期的后果还是非常严重的。</p>
                     <p class="date">2019-07-26 10:26:00</p>
                 </div>
             </a>
        </li>

    </ul>

</section>

<section  class="part noskin" >
     <div class="jsd">
        <h3>精选推荐</h3>
           <a href="#" class="more">额度：10万   期限：12月</a>
     </div>
         <ul class="bank_info">
              <li>
                  <div class="bank_pic"><img src="../assets/bank_1.jpg"></div>
                  <div class="bank_card">
                       <h3>华夏银行 - 普通信用卡</h3>
                       <div class="card_name"><span class="sel">信用卡</span><span>信用卡</span></div>
                       <P class="detail">
                            <span><i>--</i>利息</span> <span><i>--</i>每天</span> <span><i>15天</i>放款</span>
                       </p>
                  </div>
              </li>
               <li>
                  <div class="bank_pic"><img src="../assets/bank_1.jpg"></div>
                  <div class="bank_card">
                       <h3>华夏银行 - 普通信用卡</h3>
                       <div class="card_name"><span class="sel">信用卡</span><span>信用卡</span></div>
                       <P class="detail">
                            <span><i>--</i>利息</span> <span><i>--</i>每天</span> <span><i>15天</i>放款</span>
                       </p>
                  </div>
              </li>
              <li>
                  <div class="bank_pic"><img src="../assets/bank_1.jpg"></div>
                  <div class="bank_card">
                       <h3>华夏银行 - 普通信用卡</h3>
                       <div class="card_name"><span class="sel">信用卡</span><span>信用卡</span></div>
                       <P class="detail">
                            <span><i>--</i>利息</span> <span><i>--</i>每天</span> <span><i>15天</i>放款</span>
                       </p>
                  </div>
              </li>
         </ul>
</section>

  </div>

</template>
<style>


</style>

  <script>
      let htmlWidth = document.documentElement.clientWidth || document.body.clientWidth;
      //得到html的Dom元素
      let htmlDom = document.getElementsByTagName('html')[0];
      //设置根元素字体大小
      if(htmlWidth>750){htmlWidth=750}
      htmlDom.style.fontSize = htmlWidth / 10 + 'px';
    </script>
<script>
import { Indicator } from "mint-ui"
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'home',
  components: {
    HelloWorld
  },
  methods: {
    
  },
  created() {
    // Indicator.open('cmm');
  }
}
</script>




<style lang="scss">

@import "../assets/style/common.css";

.noskin{ background:none;}

.top{position: relative; border-bottom: px2rem(0.5) solid #f3f3f3; padding:0 px2rem(10) px2rem(10);text-align: left;}
.top img{ width: px2rem(120); }


.list_nav{  display: flex;  box-sizing: border-box; height:px2rem(105) ; }
.list_nav li{ flex-grow: 4; font-size: px2rem(16) ; text-align: center; }
.list_nav li a{ display: block;padding:px2rem(20)}
.list_nav li img{ height: px2rem(50); }
.list_nav li p{padding-top: px2rem(8)}
.banner{ height:px2rem(90); padding:px2rem(15) }
.banner img{height:px2rem(90); width: 100%;}

.jsd{ position: relative; background: #fff;}
.jsd h3{ font-size:px2rem(24); background:url(../assets/tit_bg.png) no-repeat px2rem(15) px2rem(20); background-size:px2rem(4) px2rem(25) ; padding: px2rem(15) 0 px2rem(15)  px2rem(30); text-align: left;}
.jsd a.more{ display: block; position:absolute; top:px2rem(18); right: px2rem(10);font-size: px2rem(14) ; color: #999;}
.jsd_tag{ display:flex; flex-wrap: wrap;padding: 0 px2rem(10);}
.jsd_tag li{ font-size:px2rem(14);color: #777;}
.jsd_tag li a{ display: block; background: #eee;margin:0 0 px2rem(14) px2rem(10); padding: px2rem(5) px2rem(10); border-radius: px2rem(20); }


.jsd_list{ border-top: px2rem(0.5) solid #f3f3f3; margin-top:px2rem(5);    display: flex;    flex-wrap: wrap; padding: 15px 20px 5px 20px;  }
.jsd_list li{padding: 0 20px 10px 15px;box-sizing: border-box;}
.jsd_list li a{display: block; position: relative;}
.jsd_list li p img{ width: 40px; height:40px;}
.jsd_list li h4{ font-size: 12px; color: #666; font-weight: normal;}
.jsd_list li i{ position: absolute; font-style: normal; right: -22px;top:-5px;font-size: 12px;background:url(../assets/jb_tit.png) no-repeat ; background-size:100% 100%; width: 24px; height: 15px; color: #fff; }

.loan_gl li { clear: both; position: relative; padding:0 10px 8px 10px; border-bottom: 1px solid #f3f3f3; margin-bottom: 13px;}
.loan_gl li a{ display: inline-block; width: 100%; height: 100%;}
.loan_gl li img.pic{ width: 110px; height: 65px; position:absolute;left: 10px;}
.info{ margin-left: 120px; }
.info h4.title{white-space: nowrap;overflow: hidden;text-overflow: ellipsis;font-size: 15px; font-weight: normal; color: #222; line-height: 23px;}
.info p.content{ color: #666; font-size: 14px;    overflow: hidden;text-overflow: ellipsis; white-space: nowrap;line-height: 23px;}
.info p.date{color: #999; font-size: 12px; text-align: left;line-height: 23px; background:url(../assets/icon_time.png) no-repeat left ; padding-left:20px;background-size:15px 15px;}


.bank_info{border-top: px2rem(0.5) solid #f3f3f3;  }
.bank_info li{ position: relative; clear: both; padding: 15px;margin-bottom: 10px; background: #fff; }
.bank_pic{ position: absolute; left: 15px;}
.bank_pic img{ width: 50px; height: 50px; padding: 10px; border: 1px solid #ddd;border-radius:10px;}
.bank_card{margin-left:80px; text-align: left; }
.bank_card h3{ font-size: 16px; font-weight: normal;}
.card_name { line-height: 0; padding: 8px 0;}
.card_name span { border: 1px solid #e4e4e4; font-size: 12px; color: #9b9b9b;line-height: 20px; padding:2px 4px; display: inline-block; margin:4px 8px 0px 0px;}
.card_name span.sel{ background:#ff6400; color: #fff; }
.bank_card p.detail{ font-size: 14px;}
.bank_card p.detail span{padding-right: 25px;}
.bank_card p.detail span i{ color: #ff6400;   display: inline-block;font-style: normal;padding-right: 5px; }
/*
.home {
  .top{
    position: relative;
    height: px2rem(48);
    padding: px2rem(14) 0 0 px2rem(14);
    box-sizing: border-box;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    .logo{
      width: px2rem(104);
    }
    .city{
      position: absolute;
      z-index: 2;
      top: .54rem;
      right: 6.4px;
      right: .4rem;
      color: #999;
      height: px2rem(24);
      padding: .96px 3.84px 0;
      padding: .06rem .24rem 0;
      background: #e8e8ea;
      font-size: 5.12px;
      font-size: .32rem;
      border-radius: .27rem;
      img{
        height: px2rem(14);
      }
    }
  }
}
*/
</style>